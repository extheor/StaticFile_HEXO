/**
 * 登录子应用（首页路由）
 */

const express = require("express");
const log = require("../middleware/log");

const User = require("../model/user");

// 登录子应用
const loginApp = express();

// 加载登录页面
loginApp.get("/", (req, res) => {
  res.render("login", { msg: "" });
});

// 实现登录操作
loginApp.post("/", (req, res, next) => {
  let { username, password } = req.body;
  User.login(username, password)
    .then((results) => {
      if (results) {
        req.log = {
          time: new Date(),
          handle: "登录",
          ip: req.ip.split(":")[3],
        };
        log.add(req, res, next);
        // session存储（key=value）
        req.session.user = results;
        res.redirect("/");
      } else {
        res.render("login", { msg: "登录失败！用户名或密码错误" });
      }
    })
    .catch((err) => {
      next(err);
    });
});

// 把这个子应用导出去
module.exports = loginApp;
