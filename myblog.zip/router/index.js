/**
 * 首页子应用（首页路由）
 */

const express = require("express");
const article = require("../middleware/article");
const category = require("../middleware/category");
const auth = require("../middleware/auth");

// 首页子应用
const indexApp = express();

indexApp.use(auth.getUser);

// 加载首页页面
indexApp.get(
  "/",
  [article.getHot, article.getList, category.getList],
  (req, res) => {
    let { hots, articles, categories, user } = req;
    res.render("index", { hots, articles, categories, user });
  }
);

// 把这个子应用导出去
module.exports = indexApp;
